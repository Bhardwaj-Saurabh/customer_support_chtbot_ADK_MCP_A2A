---
description: Generate or refresh docs/compliance-checklist.md for this project
---

Produce the §8 per-project compliance checklist for the current project.

1. Load `diai-compliance-review` and `diai-rulebook`.
2. Determine the layer first — conditional items depend on it.
3. For every item, evaluate against the actual codebase and mark `PASS`, `FAIL`, or `N/A with reason`. Do not leave items blank and do not guess.
4. Include the conditional sections only where their trigger is true (MCP, strategic layer, EU AI Act high-risk).
5. Note any item affected by the contradictions in `diai-known-issues`, stating which reading you applied.

Write to `docs/compliance-checklist.md`. Show me the diff before writing if the file already exists.

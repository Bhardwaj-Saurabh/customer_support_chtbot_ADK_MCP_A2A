---
description: Verify every LLM call in this project routes through the AI Gateway
---

Audit LLM access across the current project.

1. Load `diai-gateway-routing`.
2. Find every place a model is called. Search for provider SDK imports, chat client construction, and HTTP calls to provider-shaped endpoints.
3. For each, determine: does it route through the gateway, and does it carry `agent_id`, `team_id`, `project_id`, and a correlation ID?
4. Check retry and error handling covers rate limit, budget exceeded, and circuit open.
5. Separately list every `DefaultAzureCredential` construction and classify each as gateway authentication, permitted data-plane access, or a §4.1 violation. Do not report the first two as violations.

Report findings with file and line. Propose the fix for each violation. Do not modify files.

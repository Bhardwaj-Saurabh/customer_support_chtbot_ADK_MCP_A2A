---
description: Add a new capability to this agent, compliant with the A2A contract
---

Add a new capability named in $ARGUMENTS to the current agent.

Before writing anything:
1. Load `diai-a2a-protocol`, `diai-agent-sizing`, and `diai-semantic-plane`.
2. Check that adding this capability does not break the four sizing tests. If it introduces a second business function or a second domain of expertise, stop and say so — it probably belongs in a different agent.

Then:
3. Follow the existing registration pattern in this codebase. Read how current capabilities register before inventing a new way.
4. Define the typed input and output models. The response must carry `duration_ms`, `tokens`, `cost`, `confidence`, and correlation and parent-span IDs.
5. Consume `business_context` from the request rather than ignoring it.
6. Any threshold, policy, or routing rule goes to the semantic plane, not into the code.
7. Add a unit test and an A2A contract test under `tests/`.
8. Add an eval case for the new capability.

State the governing rule as a comment on each non-obvious decision.

---
description: Run a DI AI Framework compliance review and produce a severity-tiered report
---

Review the current project (or the files named in $ARGUMENTS, if given) against the DI AI Framework.

1. Load the `diai-compliance-review` skill and follow its review order.
2. Scan for anti-patterns first — these are immediate FAILs.
3. Check the required documents exist: `docs/layer-classification.md`, `docs/eu-ai-act-classification.md`, `docs/compliance-checklist.md`, `observability/cat-pst-classification.md`.
4. Walk the ten §4 rules in order, loading the matching skill for each.
5. Apply the §15 sizing tests.
6. Triage before reporting — consult `diai-known-issues` for the disputed rules, and do not report a `DefaultAzureCredential` used for gateway authentication as a §4.1 violation.

Output the severity-tiered report format from the skill. Every finding must carry a rule section, a location, and a compliant alternative.

Do not modify any files.

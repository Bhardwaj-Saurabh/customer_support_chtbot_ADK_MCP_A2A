---
description: Classify this component's DI AI Framework layer and run the four sizing tests
---

Classify the component in the current working directory against the DI AI Framework.

1. Load the `diai-layer-classification` and `diai-agent-sizing` skills.
2. Read the README, any existing `docs/layer-classification.md`, and enough of `src/` to understand what the component actually does.
3. Apply the §3 decision procedure in order and state the layer with your reasoning.
4. Run all four sizing tests. For each, state PASS or FAIL with the specific evidence from this codebase.
5. If any sizing test fails, propose how to split the component and what orchestration it would need.
6. Produce the content for `docs/layer-classification.md`. Ask before writing the file.

Do not assume the existing classification is correct — verify it.

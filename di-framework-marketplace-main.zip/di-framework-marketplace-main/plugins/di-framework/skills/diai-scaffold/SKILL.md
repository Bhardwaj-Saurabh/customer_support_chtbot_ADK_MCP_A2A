---
name: diai-scaffold
description: DI AI Framework §7 — the mandatory project structure every new tactical agent must produce, and the twelve-phase development process with its per-phase compliance checkpoints. Use when starting a new agent project, when creating directories or a repository layout, when a required document such as compliance-checklist.md or architecture.md is missing, when setting up CI, or when the user asks what files a compliant project needs.
---

# §7 — Mandatory scaffold · the twelve-phase process

## Required structure — missing any of this is a scaffold failure

```
<project-root>/
├── CLAUDE.md                        # framework directive, copied at creation
├── README.md                        # includes layer classification statement
├── docs/
│   ├── layer-classification.md      # §3
│   ├── eu-ai-act-classification.md  # §4.8 — mandatory
│   ├── compliance-checklist.md      # §8
│   └── architecture.md
├── src/                             # agent code, single language
├── tools/                           # tool containers, each its own Dockerfile
├── deploy/
│   ├── Dockerfile
│   ├── k8s/
│   │   ├── deployment.yaml          # limits, probes, sidecars
│   │   ├── service.yaml
│   │   ├── configmap.yaml
│   │   └── secret-refs.yaml         # references only, no values
│   └── otel-collector-config.yaml
├── observability/
│   ├── metrics.md                   # business + technical metrics
│   ├── cat-pst-classification.md    # log-by-log policy
│   └── dashboards/
├── tests/
│   ├── unit/
│   ├── integration/
│   └── compliance/                  # A2A contract, gateway routing tests
└── .github/workflows/
    └── ci.yaml                      # runs validation + eval suite
```

**Do not hand-roll this.** Use the organisation's scaffolding tool. Hand-rolling a compliant agent is estimated internally at ~13 engineer-days before any business logic.

## The twelve-phase process

| Phase | Name | Framework additions |
|---|---|---|
| 1 | Problem Definition | Layer classification, workflow-vs-orchestration, dependencies, risk |
| 2 | Build Prototype | Protocol foundations, gateway abstraction, semantic-plane abstraction, tool interfaces |
| 3 | Define Metrics | STAR methodology, framework metrics, observability plan |
| 4 | Define Evals | Hierarchical evals, compliance evals, unacceptable-response criteria |
| 5 | Build PoC | Scope, SAOIG checkpoint, user feedback |
| 6 | Instrument | OTel, CAT/PST, tools, A2A, MCP if applicable, gateway, semantic plane, cost |
| 7 | Observability | Platform integration, eval rules storage |
| 8 | Evaluate Traced Data | Framework metrics against captured traces |
| 9 | Evaluate Application | Semantic integration validation |
| 10 | Expose Application | Containerised deployment |
| 11 | Continuous Development | Governance loop, pre-deployment evals, regression |
| 12 | Monitoring & Alerting | Cost management via the gateway, budget alerts |

Each phase has a **Framework Compliance Checkpoint**. Do not skip forward.

## SAOIG enterprise readiness

**S**ecurity/ethics/compliance · **A**rchitecture (modular, scalable, stateless, resilient, documented) · **O**bservable · **I**ntegration & interoperability · **G**overnance & maintainability.

**Source:** `DIAI_Framework.md` §7, §8 · `AI Engineering Handbook` Process Overview and Phases 1–12

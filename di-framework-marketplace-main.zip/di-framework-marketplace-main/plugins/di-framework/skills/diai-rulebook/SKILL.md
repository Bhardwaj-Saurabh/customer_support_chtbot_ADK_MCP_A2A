---
name: diai-rulebook
description: The DI AI Framework rulebook router — the ten unconditional MUST rules, the three-layer architecture, conditional rules, and where genuine choices exist. ALWAYS load this skill first when designing, scoping, building, reviewing, or evaluating any AI agent at Delaware; when the user mentions the DI AI Framework, DI AI Rulebook, tactical agent, strategic agent, orchestrator, A2A, AI Gateway, semantic plane, CAT/PST, SAOIG, or framework compliance; or when asked "how should we do X according to the framework". It routes to the specific rule skills and states which rules apply to the component at hand.
---

# DI AI Framework — rulebook router

The framework is a **specification, not guidance**. Requirements, not suggestions. No PoC exemptions. Deployment is blocked on any FAIL.

## Do this first, every time

1. **Classify the layer** (see `diai-layer-classification`). The layer determines which rules apply.
2. **Size the agent** (see `diai-agent-sizing`). Wrong sizing cascades into everything else.
3. **Then** apply the ten unconditional rules below.

## The ten unconditional rules (§4)

| § | Rule | Skill |
|---|---|---|
| 4.1 | All LLM calls route through the AI Gateway | `diai-gateway-routing` |
| 4.2 | A2A protocol on a separate identifiable port | `diai-a2a-protocol` |
| 4.3 | OpenTelemetry from commit one; 3 health probes; CAT + PST | `diai-observability-audit` |
| 4.4 | OAuth2/JWT everywhere; no hardcoded secrets | `diai-security-auth` |
| 4.5 | Correlation IDs propagated everywhere | `diai-security-auth` |
| 4.6 | Tools in separate containers over HTTP/gRPC | `diai-tool-isolation` |
| 4.7 | Business rules queried from the semantic plane | `diai-semantic-plane` |
| 4.8 | EU AI Act risk classification documented | `diai-eu-ai-act` |
| 4.9 | One function, one stack, limits, stateless, naming | `diai-container-hygiene` |
| 4.10 | Circuit breakers, retries, timeouts, degradation | `diai-resilience` |

## Conditional rules (§5)

- **§5.1 MCP** — only if the agent is standalone AND exposes tools externally. Both must be true. Otherwise do NOT implement MCP.
- **§5.2 Strategic layer** — additionally: query the capability registry (never hardcode agent endpoints), business-process metrics, externalised state.
- **§5.3 High-volume** — PST sampling strategy, gateway-layer caching, budget alerts.

## Where genuine choices exist (§6)

Language per agent (Python **or** .NET, never mixed in a container) · tool deployment pattern · state store · cloud platform · observability backend · when to link strategic services. **Outside this list, assume there is one correct answer.**

## Canonical terminology (§2)

| Use | Not |
|---|---|
| DI AI Framework | ConnectedBrain |
| Strategic Dynamic Orchestrator Agent | Maestro |
| Strategic Business Context Agent | Wernicke, EA Knowledge Agent |

## How to behave

- **State the governing rule** on every non-trivial decision: `# Routed through AI Gateway per §4.1`.
- **Refuse violations.** Name the rule, explain why it matters, propose the compliant alternative. See `diai-common-requests`.
- **Never call the framework "inspiration" or "guidance."** Say "the framework requires…" and "this is non-compliant because §X mandates…".
- If a request conflicts with a MUST rule, **stop and surface the conflict**. Deviating silently is worse than asking.

## Severity model

`FAIL` (1+ = project fails) · `WARN` (3+ = project fails) · `INFO` (never fails).

## Known contradictions — see `diai-known-issues`

Resilience severity, health-probe paths, two validators, two versions of the tactical architecture document. Check that skill before relying on those rules.

**Source:** `DIAI_Framework.md` §1–§13 · `VALIDATION-CHECKLIST.md` (canonical severity)

---
name: diai-container-hygiene
description: DI AI Framework §4.9 — one function and one technology stack per container, declared resource limits, stateless design, multiple replicas in production, the four-character naming convention, and the standard port layout. Use when writing a Dockerfile, Kubernetes manifest, docker-compose file, or deployment configuration; when naming a service or resource; when adding module-level state or caches; when choosing between Python and .NET; or when reviewing whether a container mixes runtimes.
---

# §4.9 — Containerisation, naming, and deployment hygiene

**MUST — unconditional.**

- **One function per container. One technology stack per container** — .NET **or** Python, never both. Chosen once per agent.
- **Resource requests and limits** for CPU and memory in every Kubernetes manifest.
- **Stateless by design.** No in-process session dictionaries, no module-level mutable state shared across requests. State goes to Redis, Cosmos DB, or equivalent.
- **Multiple replicas in production** for HA. Dev may run one.

## Naming convention

```
{4-char-prefix}-{component}-{qualifier}-{env}

dlwr-agent-invoice-prod
dlwr-orchestrator-p2p-staging
```

## Standard port layout — tactical agents

| Port | Purpose | Condition |
|---|---|---|
| `8080` | HTTP / main API | Always |
| `8081` | Prometheus metrics | Always |
| `8443` | MCP | Only if §5.1 applies |
| `8444` | A2A | Mandatory |

## Forbidden

```python
user_sessions = {}                     # ❌ §4.9 — module-level mutable state
```

```dockerfile
FROM python:3.11                       # ❌ §4.9 — mixed stacks
RUN apt-get install -y dotnet-sdk-8.0
```

## Container build expectations

Multi-stage build · pinned base image (never `:latest`) · runs as non-root · read-only root filesystem where possible · `HEALTHCHECK` defined · single entry point.

## Why

These are the baseline operational properties that let the platform team treat an agent as a citizen of the mesh rather than a snowflake.

**Source:** `DIAI_Framework.md` §4.9 · `VALIDATION-CHECKLIST.md` §1, §9 · `QUICK-REFERENCE.md` Kubernetes and Dockerfile templates

---
name: diai-tool-isolation
description: DI AI Framework §4.6 — tools must run as separate processes reached over HTTP or gRPC, never imported as libraries into agent code, in every environment including PoC and demo. Use when adding any tool to an agent — OCR, PDF parsing, search, external API connectors, validators, scrapers; when writing an import statement for something that performs work rather than provides types; when designing sidecar or shared-service deployment; or when someone argues a direct import is fine "because it's the same container anyway".
---

# §4.6 — Tool isolation

**MUST — unconditional, in every environment including PoC and demo.**

Tools — OCR, PDF parsing, external API connectors, validators — run as **separate processes accessed over the network**. Direct library imports of tool code into agent code are **strictly forbidden at every stage**.

## The three mandatory principles

1. **Process isolation** — separate containers, separate resource limits, separate failure domains. A tool crash cannot crash the agent.
2. **Network communication** — HTTP or gRPC only, **even over localhost**.
3. **Separate lifecycle** — versioned and deployed independently of the agent.

## The deployment pattern is a genuine choice

| Environment | Choose one of | Status |
|---|---|---|
| Production | Sidecar (same pod, localhost networking) | **Preferred** |
| Staging | Sidecar or hybrid | Acceptable |
| Dev / Test / PoC / Demo | Sidecar or shared tool service | Acceptable |
| **Any** | **Direct library embedding** | **FORBIDDEN** |

```python
from pdf_parser import parse_pdf                # ❌ §4.6 — forbidden everywhere
parsed = parse_pdf(doc)

parsed = (await http.post(                      # ✓ network-based
    "http://localhost:9001/parse",
    json={"document": doc},
    headers={"X-Correlation-Id": get_correlation_id()},
)).json()
```

## The distinction that matters

Sidecar-versus-shared-service is a legitimate trade-off between fault isolation and cost. **"Just import it" is not a trade-off; it is a compliance failure.**

Importing a *library* for types, models, or pure helpers is fine. Importing something that **does the work** — parses, calls out, transforms via its own logic — is a tool and must be isolated.

## Also required

- Tool containers stored in a central registry.
- Tools deployable and updatable without modifying agent code.
- Each tool has its own Dockerfile under `tools/`.

## When someone asks to skip this

"Just import the OCR library, it's the same container anyway." → **Refuse.** Direct imports are prohibited in every environment. Containerise the tool and call it over localhost HTTP — that *is* the sidecar pattern.

**Source:** `DIAI_Framework.md` §4.6 · `VALIDATION-CHECKLIST.md` §10 and "Prohibited Anti-Patterns" · `07-tactical-agent-architecture.md` "Tool Deployment Patterns" · `AI Engineering Handbook` Steps 2.5, 6.3

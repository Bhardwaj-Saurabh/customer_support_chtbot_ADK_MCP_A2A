---
name: diai-semantic-plane
description: DI AI Framework §4.7 — business rules must be queried from the Strategic Business Context Agent via the semantic plane, never hardcoded in code, YAML, persona prompts, or environment variables. Use whenever writing a threshold, limit, approval rule, routing decision, customer-tier policy, validation criterion, SLA definition, confidence cutoff, or compliance rule; when reviewing if/else branches on business values; when writing persona or config YAML; or when deciding whether something counts as workflow logic or business logic.
---

# §4.7 — Semantic plane integration

**MUST — unconditional.** Business rules are queried dynamically from the Strategic Business Context Agent. They must **not** live in YAML files, persona prompts, environment variables, or if/else ladders.

## The decision test

> **Would a business stakeholder want to change this without a code deployment?**
> **YES** → business logic → query the semantic plane.
> **NO** → workflow logic → hardcoding is fine.

| MUST be queried (business logic) | MAY be hardcoded (workflow logic) |
|---|---|
| Approval thresholds and limits | Workflow sequence — step A → B → C |
| Routing rules — which team or agent | Technical retry and error-handling patterns |
| Customer-tier policies, VIP, SLA definitions | Tool orchestration logic |
| Validation criteria | Data transformation steps |
| Compliance and regulatory rules | Loop and branching mechanics |
| Quality/confidence thresholds a business owner would tune | |

```python
if invoice.amount > 10000:                      # ❌ §4.7 — business rule
    route_to = "cfo_approval"

# quality_threshold: 0.85                       # ❌ §4.7 — even in persona YAML

threshold = await context.get_rule(             # ✓ queried
    domain="approvals", key="cfo_threshold")
```

## Additional obligations

- **Advertise capabilities** to the semantic plane at startup (capability registration).
- Client has **caching** and **graceful degradation**.
- **Handle change notifications** for process updates.
- **When the semantic plane is unreachable AND the cache is empty, raise — do not invent a default.** Silent defaults defeat the entire rule.

## Why the framework is strict here

Hardcoded business rules are the largest source of maintenance debt in enterprise AI. They block the governance model (business owners cannot tune policy), break explainability (the EU AI Act needs a traceable rule), and force code deployments for policy changes.

## When someone asks to skip this

"Add these business rules to the persona prompt." → **Refuse for business rules** — thresholds, policies, routing. Workflow *sequencing* in a prompt is fine. Route business rules through the Strategic Business Context Agent client and cite §4.7.

**Source:** `DIAI_Framework.md` §4.7 · `VALIDATION-CHECKLIST.md` §7 (five MUST items) · `07-tactical-agent-architecture.md` "Workflow Logic vs. Business Logic" · `AI Engineering Handbook` Steps 2.4, 6.7

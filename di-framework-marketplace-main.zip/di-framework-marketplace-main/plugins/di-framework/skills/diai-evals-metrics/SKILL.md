---
name: diai-evals-metrics
description: DI AI Framework metrics and evaluation — the STAR methodology, mandatory gateway and A2A metrics, the three-level hierarchical evaluation architecture, and the mandatory framework compliance eval suite. Use when defining success metrics or KPIs for an agent, when building or extending an eval suite, when writing test datasets or golden sets, when adding LLM-as-judge scoring, when setting up dashboards or alerts, or when asked how to measure whether an agent is working.
---

# Metrics and evaluation

## STAR methodology

| | Element | Define |
|---|---|---|
| **S** | Strategic Metric | One north-star metric encapsulating primary business value, measurable through the observability platform. Examples: cycle-time reduction, extraction accuracy, cost per transaction, NPS. |
| **T** | Supporting Metrics | **Technical** — latency, throughput, accuracy, gateway response times, uptime. **Operational** — semantic-plane query success, exception/escalation rates, cost per operation, A2A performance. **Business** — straight-through processing, satisfaction, ROI. |
| **A** | Actionable OKRs | Specific measurable objectives, time-bound key results, measured via OTel traces, the eval framework, gateway cost metering, A2A completion tracking. |
| **R** | Responsive Evaluation | Automated dashboards, real-time alerts on critical metrics, routine reviews. |

## Mandatory framework metrics

- **AI Gateway** — cost allocation by agent/team/project · token usage by model and agent · request rate and rate-limit tracking · gateway latency.
- **A2A** (tactical agents) — invocation counts, completion tracking, protocol performance.

## Hierarchical evaluation architecture

| Level | Purpose | Content |
|---|---|---|
| **Operational** | Node-by-node performance — unit tests for individual components | Accuracy per step, field-level extraction accuracy, format coverage, latency targets, ground-truth datasets |
| **Tactical** | Workflow-wide intelligence — emergent properties | End-to-end success rates, business-rule adherence, cost efficiency per workflow, multi-step reasoning quality, context preservation |
| **Strategic** | User experience outcomes | Satisfaction collection, business impact, cycle-time reduction, STP rates, exception quality |

## Framework compliance evals — mandatory

Compliance is an **eval category**, not only a validator concern. The workflow-vs-orchestration boundary eval implements six executable tests:

1. **Single Purpose** — one sentence, no "and" between functions
2. **Domain Expertise** — all steps need the same specialised knowledge
3. **Unified Goal** — all tools serve the same objective
4. **Independent Value** — internal steps have no standalone value
5. **A2A Usage** — agent does NOT call other tactical agents via A2A
6. **Multi-Function** — agent does NOT handle multiple distinct capabilities

See `diai-agent-sizing` for the pass/fail examples.

## Testing expectations (SHOULD)

Pre-deployment eval suite against every new version · regression validation (no worse than previous) · framework compliance validation · load testing after significant changes.

**Source:** `AI Engineering Handbook` Steps 3.1, 3.2, 4.1, 4.2 · `VALIDATION-CHECKLIST.md` "STAR Methodology", "Hierarchical Evaluation Architecture", §12

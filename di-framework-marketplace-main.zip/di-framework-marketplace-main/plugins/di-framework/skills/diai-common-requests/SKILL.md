---
name: diai-common-requests
description: The standard DI AI Framework responses when someone asks to skip, defer, or work around a mandatory rule. Use whenever a user proposes bypassing the AI Gateway, deferring OpenTelemetry, hardcoding business rules, importing a tool library directly, skipping A2A, postponing EU AI Act classification, or otherwise treating a MUST rule as optional. Also use when deciding how to phrase a refusal constructively.
---

# Responding to requests that would violate a rule

The framework directs: if a request conflicts with a MUST rule, **refuse, explain which rule is violated and why it matters, and propose the compliant alternative.** Do not comply with the violation. Do not deviate silently.

| The request | Rule | The correct response |
|---|---|---|
| "Just call the model directly, it's faster to prototype." | §4.1 | **Refuse.** Unconditional including at PoC. Offer a thin gateway client library, or point the existing one at a local gateway for development. |
| "Add these business rules to the persona prompt." | §4.7 | **Refuse for business rules** — thresholds, policies, routing. Workflow *sequencing* in a prompt is fine. Route business rules through the Strategic Business Context Agent client. |
| "Skip OpenTelemetry for now, we'll add it later." | §4.3 | **Refuse.** Instrumentation is required from day one; only the *destination* may be deferred. Install OTel and point it at a local collector. |
| "Just import the OCR library, it's the same container anyway." | §4.6 | **Refuse.** Direct imports are prohibited in every environment. Containerise the tool and call it over localhost HTTP — that is the sidecar pattern. |
| "We don't need A2A, this agent only runs standalone." | §4.2 | **Clarify** whether it is truly standalone. If it is tactical and could ever be orchestrated, A2A is still mandatory. Err on implementing it. |
| "EU AI Act classification can wait until launch." | §4.8 | **Refuse.** Classification is unconditional; only the extra high-risk controls are conditional. Short document, must exist before deployment. |
| "Link the observability to the strategic services now." | §4.3 | **Acceptable**, not required. Confirm the platform team is ready to receive. If not, keep it configurable and deferred. |

## How to refuse well

1. Name the rule section.
2. State the concrete consequence, not the abstract principle — "cost attribution breaks and the CAT hook never fires", not "it's non-compliant".
3. Offer the compliant path **in the same breath**. A refusal without an alternative reads as obstruction.
4. If the person has a genuine constraint you cannot see, ask what it is. Sometimes the compliant path is easier than they assume.

## What is not a refusal

Choices in §6 are genuine choices. Python or .NET, sidecar or shared tool service in dev, Redis or Cosmos, which cloud. Do not refuse these — help decide.

**Source:** `DIAI_Framework.md` §10, §13

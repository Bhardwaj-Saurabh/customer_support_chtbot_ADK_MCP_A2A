---
name: diai-security-auth
description: DI AI Framework §4.4 and §4.5 — OAuth2/JWT authentication on every endpoint, zero trust, secret management, TLS 1.3 and AES-256-GCM encryption, RBAC, and correlation ID propagation across every outbound call. Use when adding authentication or middleware, handling tokens or credentials, configuring secrets or key vaults, writing anything that looks like an API key or connection string, setting up request context, or propagating trace headers between services.
---

# §4.4 Security · §4.5 Correlation

**MUST — unconditional.**

## §4.4 Security and authentication

- **OAuth2/JWT on every agent endpoint.** A2A, MCP if present, REST — all closed. Health endpoints may be open to the cluster.
- **Zero trust between components.** No implicit trust based on network location.
- **No hardcoded secrets anywhere.** Platform secret manager (Azure Key Vault, SAP Credential Store, cloud equivalent). Secrets enter the container as env vars injected at runtime — never baked into images.
- **Encryption:** TLS 1.3 in transit, AES-256-GCM at rest.
- **RBAC** on all management and configuration surfaces.
- **Comprehensive audit logging** of security-relevant actions, routed to CAT.

```python
API_KEY = "sk-abc123..."                       # ❌ §4.4
CONN    = "Server=...;Password=hunter2"        # ❌ §4.4

api_key = os.environ["GATEWAY_KEY"]            # ✓ injected at runtime
# populated from Key Vault via secret-refs.yaml — no value in the repo
```

Manifests reference secrets; they never contain values. Use `deploy/k8s/secret-refs.yaml`.

## §4.5 Correlation IDs and trace context

- Every **inbound** request carries or is assigned a correlation ID.
- Every **outbound** call propagates it — gateway, tools, other agents, semantic plane.
- Every log line, CAT entry, PST entry, and metric trace exemplar includes it.
- **W3C Trace Context** headers for cross-service span linkage.

Implement as middleware that accepts an incoming `X-Correlation-Id` or assigns a UUID, binds it into context vars for the structured logger, and echoes it on the response.

### Why this is not bureaucracy

Without correlation IDs, CAT cannot reconstruct a user interaction, PST cannot diagnose a cross-agent failure, and cost attribution cannot tie a spend spike to the originating business process.

## Identity flows

Where the gateway or a downstream service supports it, prefer **on-behalf-of** exchange for user-initiated flows so the caller's identity reaches the dependency, and app-only credentials for autonomous chains. Make the choice explicit in configuration rather than implicit in whichever credential the environment happens to provide. Never accept a pre-minted static bearer outside local development.

**Source:** `DIAI_Framework.md` §4.4, §4.5, §9 · `VALIDATION-CHECKLIST.md` §4, §6 · `07-tactical-agent-architecture.md` "Security Implementation"

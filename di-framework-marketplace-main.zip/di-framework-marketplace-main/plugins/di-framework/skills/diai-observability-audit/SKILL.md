---
name: diai-observability-audit
description: DI AI Framework §4.3 — OpenTelemetry instrumentation from the first commit, the three mandatory health probes, and the dual CAT/PST audit trail with per-log classification. Use when adding logging, tracing, metrics, or health endpoints; when writing anything that logs a prompt, response, user ID, or business decision; when configuring an OTel collector or exporter; when designing retention or encryption for logs; or when someone proposes deferring observability to a later phase.
---

# §4.3 — Observability, health, and dual audit trails

**MUST — unconditional.** Instrumentation in the **first commit**. Not optional, not deferred, not a phase-two item.

## OpenTelemetry

- Distributed tracing on every request path.
- **Technical** metrics: latency p50/p95/p99, error rate, throughput.
- **Business** metrics: workflow completion, straight-through-processing rate, cycle time, or the domain equivalent.
- Structured logging with correlation IDs and trace-context propagation across service boundaries.

## Health endpoints

Three probes: `/health/live`, `/health/ready`, `/health/startup`.

> ⚠ `QUICK-REFERENCE.md` says `/health` and `/ready`. The checklist names no paths. **Implement all three literals** — that satisfies every source. See `diai-known-issues`.

## Dual audit trails — classify every log at source

|  | **CAT** — Confidential Audit Trail | **PST** — Platform Support Trail |
|---|---|---|
| Purpose | Governance, compliance transparency | Debugging, monitoring, performance |
| Content | Full prompts, full responses, user IDs, business decisions | Anonymised patterns, system metrics, diagnostics. **No PII** |
| Encryption | AES-256-GCM at rest, HSM keys, 90-day rotation | Standard |
| Retention | Long-term per regulatory need (7 years in the reference config) | ~90 days |
| Access | Restricted | Dev and ops |

```python
cat("llm_call_completed",                  # ✓ confidential, encrypted
    prompt=prompt, response=response,
    user_id=principal.oid,
    correlation_id=get_correlation_id())

pst("llm_call_completed",                  # ✓ anonymised, no PII
    model=model, tokens=usage.total, latency_ms=elapsed,
    correlation_id=get_correlation_id())
```

**Every log statement MUST be classified CAT or PST at the source. Do not mix.**

## Reconfigurability

Linking to strategic services (Strategic Business Context Agent for metric routing, capability registry, central observability platform) **may** be deferred. The architecture must support switching them on **without code changes** — env vars and feature flags. Code must treat them as optional-but-pluggable, never assuming absence.

## When someone asks to skip this

"Skip OpenTelemetry for now, we'll add it later." → **Refuse.** Instrumentation is required from day one; only the *destination* may be deferred. Install OTel and point it at a local collector.

**Source:** `DIAI_Framework.md` §4.3 · `VALIDATION-CHECKLIST.md` §4, §5 · `08-audit-logging-architecture.md` · `AI Engineering Handbook` Steps 6.1, 6.2, 7.1

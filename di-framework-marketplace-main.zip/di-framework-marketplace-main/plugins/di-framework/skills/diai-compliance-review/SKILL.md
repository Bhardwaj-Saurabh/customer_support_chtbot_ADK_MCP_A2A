---
name: diai-compliance-review
description: Review code, a pull request, or a whole agent project against the DI AI Framework and produce a severity-tiered FAIL/WARN/PASS report mapped to rule sections. Use when asked to review, audit, or check compliance of an agent; when writing a PR description that must list framework sections addressed; when preparing for an architecture review; when filling in docs/compliance-checklist.md; or when the user asks "is this compliant".
---

# Compliance review

## Severity model

| Severity | Threshold | Meaning |
|---|---|---|
| **FAIL** | 1 or more | Project fails. A MUST requirement is violated. |
| **WARN** | 3 or more | Project fails. SHOULD requirements. |
| **INFO** | Any | Recommendations only. Never fails. |

`PROJECT_STATUS = if (FAIL_COUNT >= 1 OR WARN_COUNT >= 3) then "FAIL" else "PASS"`

## Review order — fastest signal first

1. **Anti-patterns** (immediate FAIL). Scan for: `import openai` / `import anthropic` · `OpenAI(` / `AzureOpenAI(` at a provider URL · hardcoded `sk-` or `AKIA` literals or `api_key =` assignments · business thresholds in `if` branches or persona YAML · direct tool imports · mixed stacks in a Dockerfile · module-level mutable dicts · missing A2A on a tactical agent · tactical agent calling other agents via A2A.
2. **Required documents.** `docs/layer-classification.md` · `docs/eu-ai-act-classification.md` · `docs/compliance-checklist.md` · `observability/cat-pst-classification.md`.
3. **The ten §4 rules** in order. Load the matching skill for each.
4. **Sizing tests** (§15) — see `diai-agent-sizing`.
5. **Conditional rules** — MCP only if standalone AND external tools; §5.2 if strategic.

## Report format

```
=== DI AI Framework Compliance Review ===

FAIL (MUST):
  §4.1  src/agent/llm.py:14 — direct openai import bypasses the gateway
        → Route through the gateway client; add cost-allocation metadata

WARN (SHOULD):
  §15   Agent description contains "and" between business functions

INFO (COULD):
  §5.3  No PST sampling strategy defined

STATUS: FAIL — 1 MUST violation
```

Every finding names the **rule section**, the **location**, and the **compliant alternative**. A finding without a remediation is not a finding, it is a complaint.

## Triage before trusting a tool

Automated checks produce false positives. Before reporting:

- `DefaultAzureCredential` used to authenticate **to the gateway** or to a permitted data-plane service is **not** a §4.1 violation. Check the endpoint and purpose.
- Rules that grep agent source for evidence (OTel imports, resilience modules) produce **false negatives** once that code moves into a shared package. Check the dependency.
- Health-probe paths and resilience severity are disputed — see `diai-known-issues`.

## PR description requirements

List the framework sections addressed. If any MUST rule is intentionally not yet met, state **why** and **when** it will be. Reviews must produce a severity-tiered list, not prose.

**Source:** `VALIDATION-CHECKLIST.md` "Failure Criteria", "Validation Summary" · `DIAI_Framework.md` §8, §9, §11

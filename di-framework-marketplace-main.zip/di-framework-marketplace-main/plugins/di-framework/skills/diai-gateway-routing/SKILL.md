---
name: diai-gateway-routing
description: DI AI Framework §4.1 — route every LLM call through the central AI Gateway with cost-allocation metadata, retries, and correlation headers. Use whenever writing or reviewing code that calls a language model, instantiates a chat client, imports openai or anthropic, configures Azure OpenAI or Foundry, sets up an LLM client factory, or handles model errors, rate limits, or token costs. Also use when someone proposes calling a provider directly "just for the prototype".
---

# §4.1 — AI Gateway routing

**MUST — unconditional.** Every LLM call, every model, every provider, every environment including PoC.

## Requirements

- All model interactions route through the central AI Gateway.
- Agents **MUST NOT** hold provider API keys, call Azure AI Foundry directly, instantiate `OpenAI()` clients pointed at provider URLs, or use `DefaultAzureCredential` **to reach model endpoints directly**.
- Every request carries `agent_id`, `team_id`, `project_id` and a correlation ID (§4.5).
- Retry with exponential backoff. Handle gateway errors explicitly: rate limit, budget exceeded, circuit open.

## What makes something a gateway

> Because APIM or a cloud-native endpoint may *look* like a gateway, the test is not "is there something in between" but **"does it enforce the framework's policies?"**

The bar is the seven MUST items in `VALIDATION-CHECKLIST.md` §3: no direct model calls · mandatory routing · no direct provider key access · centralized token management · rate limiting · model abstraction · centralized governance.

## Forbidden

```python
import openai                                      # ❌ §4.1
response = openai.ChatCompletion.create(...)

from azure.identity import DefaultAzureCredential  # ❌ §4.1
client = AzureOpenAI(azure_endpoint="https://....openai.azure.com/",
                     credential=DefaultAzureCredential())
```

## Required

```python
gateway = GatewayClient(settings)
response = await gateway.chat(
    model=settings.llm_model,
    messages=messages,
    metadata={                                     # ✓ cost allocation, §4.1
        "agent_id":   settings.agent_id,
        "team_id":    settings.team_id,
        "project_id": settings.project_id,
    },
    headers={"X-Correlation-Id": get_correlation_id()},   # ✓ §4.5
)
```

## Credential nuance — avoid the false positive

Using `DefaultAzureCredential` to authenticate **to the gateway** is not a violation; that may be exactly how the gateway requires you to authenticate. The prohibition is on using it to reach a **model endpoint** directly. Pattern-matching on the symbol alone produces false alarms — check the endpoint and the purpose.

## When someone asks to skip this

"Just call the model directly, it's faster to prototype." → **Refuse.** §4.1 is unconditional including at PoC. Offer a thin gateway client library, or point the existing one at a local gateway for development.

**Source:** `DIAI_Framework.md` §4.1, §9, §10 · `VALIDATION-CHECKLIST.md` §3 · `09-ai-gateway-architecture.md` "Core Principles" · `AI Engineering Handbook` Steps 2.3, 6.6, 6.8

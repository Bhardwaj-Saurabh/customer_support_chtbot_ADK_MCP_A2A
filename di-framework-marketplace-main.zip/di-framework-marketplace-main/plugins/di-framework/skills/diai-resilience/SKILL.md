---
name: diai-resilience
description: DI AI Framework §4.10 — circuit breakers on every outbound dependency, retry with exponential backoff and jitter, timeouts on every outbound call, and documented graceful-degradation paths. Use when writing any outbound call to the AI Gateway, a tool, the semantic plane, or another agent; when handling transient errors; when configuring HTTP clients or timeouts; when designing fallback behaviour; when choosing a circuit-breaker library for an async service; or when reviewing an agent for cascading failure risk.
---

# §4.10 — Resilience

**MUST per `DIAI_Framework.md` §4.10.** ⚠ `VALIDATION-CHECKLIST.md` §11 lists resilience as **SHOULD (WARN)** only, with no MUST items — a severity dispute recorded in `diai-known-issues` §3. **Treat as MUST**: the controls are cheap and the failure mode they prevent is expensive.

## Requirements

- **Circuit breakers on every outbound dependency** — AI Gateway, tools, Strategic Business Context Agent, downstream agents.
- **Retry with exponential backoff plus jitter** on transient failures.
- **Timeouts on every outbound call.** No unbounded waits.
- **Graceful degradation paths documented** for: AI Gateway unavailable · semantic plane unavailable · tool unavailable · orchestrator unavailable.
- **A test proving the breaker opens on async failures.** See *Verification* below — this is not optional, and declaring a breaker is not evidence that it works.

One breaker **per dependency**, not one shared breaker — otherwise a slow tool trips the gateway path. One instance **per process, for the process's lifetime**: a breaker built per request has no memory and therefore no effect.

## ⚠ Do not use `pybreaker` in an async service

**`pybreaker` has no correct async usage without Tornado, and its failure mode is silent.** Earlier versions of this skill showed it. Agents built from that guidance — including several in MaS — carry breakers that can never open.

Verified against **pybreaker 1.4.1**, `fail_max=2`, six consecutive async failures:

```
attempt 1..6: RuntimeError(dependency is down) | state=closed fail_counter=0
state=closed  fail_counter=0  dependency invoked 6 times
```

**Mechanism.** `CircuitBreaker.__call__` builds a wrapper that calls `self.call(func, ...)` — the *synchronous* path. For an `async def` that invokes the coroutine function, immediately receives an **un-awaited coroutine object**, and raises nothing. The breaker records a **success** and hands the coroutine back; the real failure happens later, when the caller awaits, entirely outside the breaker. The async path requires `__pybreaker_call_async=True` and raises `ImportError: No module named tornado` without Tornado installed.

Every reviewable artifact looks correct — the import is present, the thresholds are sensible, the decorator is on the right method. Only a test that awaits a failure can tell the difference.

**Use an async-native breaker instead.** It must:

- `await` the guarded call **inside** its own failure accounting;
- hold the three states (closed → open → half-open) and persist transitions under a lock;
- admit a bounded number of half-open trial calls;
- treat `asyncio.CancelledError` as neither success nor failure — a caller going away says nothing about the dependency.

The framework names no library, and neither does this skill. Any implementation meeting those four points is acceptable — but verify it with the test in *Verification* below rather than trusting its README, which is how `pybreaker` got adopted in the first place.

## The shape

```python
class TransientError(Exception):
    """Worth retrying: timeout, connection reset, 429, 502, 503, 504.
    Not a 4xx business rejection — the dependency answered, it just said no."""

# One instance per dependency, created at startup, never per request.
GATEWAY_BREAKER = AsyncCircuitBreaker(name="ai_gateway", fail_max=5, reset_timeout=30)

async def call_gateway(payload: dict) -> dict:
    async def attempt() -> dict:
        async with asyncio.timeout(10):          # timeout on every outbound call
            return await gateway_client.post(payload)

    async def with_retry() -> dict:
        async for retry in AsyncRetrying(
            wait=wait_exponential_jitter(initial=1, max=20),
            stop=stop_after_attempt(4),
            retry=retry_if_exception_type(TransientError),
            reraise=True,
        ):
            with retry:
                return await attempt()
        raise AssertionError("unreachable")

    # Breaker OUTSIDE retry: one exhausted operation is ONE breaker failure.
    return await GATEWAY_BREAKER.call(with_retry)
```

**Composition order matters.** Breaker contains retry contains attempt. Inverted, four retry attempts trip a `fail_max=4` breaker on a single user request, and the breaker measures your retry policy instead of the dependency's health.

`AsyncRetrying` is shown because it composes explicitly with the breaker. Tenacity's `@retry` decorator is async-aware (it detects a coroutine function and retries correctly), so it is also valid — but it hides the composition, which is the part that is easy to get backwards.

## Verification

**A breaker is compliant only when a test proves it opens on async failures.**

```python
async def test_breaker_opens_on_async_failures():
    breaker = AsyncCircuitBreaker(name="dep", fail_max=3)
    calls = 0

    async def failing():
        nonlocal calls
        calls += 1
        raise TransientError("down")

    for _ in range(3):
        with pytest.raises(TransientError):
            await breaker.call(failing)

    assert breaker.state == "open"           # N failures opened it
    with pytest.raises(CircuitBreakerOpenError):
        await breaker.call(failing)
    assert calls == 3                        # and it now fails fast
```

A breaker that never opens is indistinguishable from a healthy dependency: no error, no log line, no metric. You discover it during the incident it was meant to prevent. Reviewers: ask for this test, not for the declaration.

## Error taxonomy

Classify failures so callers can react: `transient` (retry), `permanent` (do not retry), `validation` (caller error). The A2A response schema carries this classification — see `diai-a2a-protocol`.

Retry on transport failures **and** retryable status codes — 408, 425, 429, 502, 503, 504. A breaker should not trip on a 4xx business rejection: the dependency was reachable and answered, which is evidence of health.

## Degradation, not silence

Degrading is documented behaviour. **Silent defaults are not degradation** — particularly for the semantic plane, where inventing a business rule defeats §4.7. Degrade loudly: log to CAT and PST, return a documented status, surface it in the A2A response.

## Why

An agent that cascades failures from a slow dependency is a worse neighbour than one that fails fast and cleanly — but only if the breaker actually opens.

**Source:** `DIAI_Framework.md` §4.10 · `VALIDATION-CHECKLIST.md` §11

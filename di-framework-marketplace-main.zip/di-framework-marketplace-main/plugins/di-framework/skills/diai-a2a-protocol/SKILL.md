---
name: diai-a2a-protocol
description: DI AI Framework §4.2 — implement the mandatory Agent-to-Agent protocol surface on a tactical agent, including request and response schemas, business context passing, parent-span propagation, error codes, and the separate identifiable port. Use when building or reviewing an agent's external interface, when adding a capability, when the orchestrator needs to invoke an agent, when writing agent cards or capability registries, or when deciding which port to expose. Also use when an agent has no A2A endpoint at all.
---

# §4.2 — A2A protocol

**MUST — unconditional for all tactical agents.** An agent the Strategic Dynamic Orchestrator Agent cannot invoke is not a compliant tactical agent.

## The endpoint must expose

- **Structured request schema** — capability name, inputs, business context.
- **Structured response schema** — status, outputs, and metadata carrying `duration_ms`, `tokens`, `cost`, `confidence`, correlation and parent-span IDs.
- **Semantic context passing** — the orchestrator passes `process`, `step`, and `business_context`; the agent **consumes** them.
- **Explicit error propagation** with error codes.

## The port

The normative requirement is that the A2A port be **separate and identifiable**. Container port **8444** is the stated convention and appears throughout the tactical manifests and standard port layout.

Mounting A2A on your main HTTP port fails the separation requirement **whatever number you pick**. Use 8444 unless you have a documented reason.

Standard tactical port layout: `8080` HTTP · `8081` Prometheus · `8443` MCP (only if §5.1 applies) · `8444` A2A.

## Hard boundary

A tactical agent **MUST NOT** use A2A to orchestrate other tactical agents. That is strategic-layer behaviour and fails `VALIDATION-CHECKLIST.md` §15. If you need it, you need an orchestrator — see `diai-agent-sizing`.

## Registration pattern

Prefer a single documented extension point: a capability class or contract that self-registers, so the agent card and skill list derive from the registry rather than a hand-maintained dict. A registry that must be edited in three places will drift.

## When someone asks to skip this

"We don't need A2A, this agent only runs standalone." → Clarify whether it is *truly* standalone. If it is tactical and could ever be orchestrated, A2A is still mandatory. **Err on the side of implementing it.**

**Source:** `DIAI_Framework.md` §4.2, §4.9 · `VALIDATION-CHECKLIST.md` §2, §15 · `07-tactical-agent-architecture.md` · `AI Engineering Handbook` Step 6.4

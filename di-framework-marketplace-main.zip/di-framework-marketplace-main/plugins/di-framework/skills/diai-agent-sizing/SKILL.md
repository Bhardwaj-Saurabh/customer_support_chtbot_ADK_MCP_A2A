---
name: diai-agent-sizing
description: Apply the DI AI Framework four sizing tests and the workflow-versus-orchestration boundary to determine whether a tactical agent is correctly scoped or is secretly doing strategic orchestration. Use when defining a new agent's scope, when an agent description contains "and" between business functions, when an agent calls other agents, when deciding whether to split one agent into several, or when reviewing an agent that feels too large. Also use when the user worries that a multi-step agent is "too complex" — complexity inside one agent is usually correct.
---

# Agent sizing and the orchestration boundary

## The most misunderstood principle

> Tactical agents with **10 to 50 internal steps are normal and correct**. Multi-step execution — sequential, conditional, iterative, parallel — is expected behaviour, **not** orchestration.

Complexity **inside** one agent is fine. Coordinating **other agents** is not.

| Allowed inside a tactical agent | Requires the strategic layer |
|---|---|
| Sequential tool chains | Using A2A to call other tactical agents |
| Conditional tool selection | Coordinating multiple independent business functions |
| Iterative refinement loops | Process-level decisions: WHICH capability, not HOW to execute |
| Parallel tool execution | |

## The four sizing tests — all must pass

**1. Single Purpose.** One sentence, no "and" between distinct functions.
- ✓ "Extract structured data from invoices"
- ✗ "Process invoices **and** post to ERP"

**2. Domain Expertise.** One specialised domain only.
- ✓ Document processing
- ✗ Documents + financial policy + ERP integration

**3. Unified Goal.** All tools and steps serve the same business objective.
- ✓ OCR → Parser → Extractor → Validator (all serve extraction)
- ✗ Extractor (data) + Validator (policy) + Poster (accounting)

**4. Independent Value.** Internal steps have **no** business value when separated.
- ✓ "Format detection" is useless without full extraction
- ✗ "Invoice extraction" would be a useful standalone service

## Immediate FAIL

- Tactical agent uses A2A to orchestrate other tactical agents
- Agent handles **3+** distinct independent business functions ("Extract + Validate + Post" = 3)
- Agent spans **3+** domain expertise areas ("Documents + ERP + Workflow policies" = 3)
- Internal steps are independently valuable as separate services

## WARN

- Description contains "and" between distinct business functions
- Domain expertise spans unrelated knowledge areas (HR policies + IT infrastructure)
- 10+ steps without clear single-purpose documentation

## If a test fails

Split into separate tactical agents and introduce a strategic orchestrator to coordinate them. Do not "simplify" by merging responsibilities — that makes it worse.

## Complexity escalation path

Simple Prompts → Prompt Chaining → RAG → Agentic RAG → Single Agent → Multi-agent. **Start at the left.** Choosing multi-agent for a problem a prompt chain solves is a recognised failure mode, not sophistication.

**Source:** `VALIDATION-CHECKLIST.md` §15 and "Sizing Validation Tests" · `07-tactical-agent-architecture.md` · `AI Engineering Handbook` Steps 1.3, 4.2

---
name: diai-known-issues
description: Known contradictions and unresolved questions within the DI AI Framework specification set, and the recommended reading for each until the framework owner resolves them. Use whenever a rule about resilience severity, health-probe paths, port 8444, or validation tooling is being applied or enforced; when two framework documents appear to disagree; when building or correcting a validator; or when a compliance finding seems ambiguous.
---

# Known contradictions in the specification set

The source documents disagree in four places. Until the framework owner resolves each, apply the recommended reading and **document which reading you used**.

## 1. Two validators with different rule counts

`readme.md` and `QUICK-REFERENCE.md` describe `validate_framework.py` with **62 MUST / 18 SHOULD / 15 COULD**. The `VALIDATION-CHECKLIST.md` results template reports against **66 / 22 / 19**. A separate scaffolding CLI implements **ten** checks mapped to the ten §4 rules.

**Impact:** a pass from one tool covers a fraction of the declared surface.
**Recommended:** confirm which tool is authoritative for the project before treating a pass as compliance. Record coverage alongside the result.

## 2. Health-probe paths

| Source | Says |
|---|---|
| `DIAI_Framework.md` §4.3 | `/health/live`, `/health/ready`, `/health/startup` |
| `07-tactical-agent-architecture.md` | Both the three literals and a bare `/health`, in different manifests |
| `QUICK-REFERENCE.md` | `/health` and `/ready` |
| `VALIDATION-CHECKLIST.md` §4 | Liveness, readiness, startup probes — **names no paths** |

**Recommended:** implement all three literals from §4.3. That satisfies every source, since the checklist is path-agnostic.

## 3. Resilience severity

`DIAI_Framework.md` §4.10 places resilience among the **unconditional MUST** rules — a missing circuit breaker blocks deployment. `VALIDATION-CHECKLIST.md` §11 contains **only a SHOULD (WARN)** item and no MUST items at all.

**Recommended:** treat §4.10 as MUST. Circuit breakers, timeouts, and jittered retries are cheap; cascading failure across the agent mesh is not.

## 4. Two versions of the tactical architecture document

`07-tactical-agent-architecture.md` and `077-tactical-agent-architecture.md` differ by ~135 lines. Only the `07-` version contains **"Workflow Logic vs. Business Logic: The Critical Distinction"** — which `VALIDATION-CHECKLIST.md` §7 cites as the authority for the most consequential judgement in §4.7.

**Recommended:** use the `07-` version.

## 5. Port 8444

Present in `DIAI_Framework.md` §4.2 and §4.9, the tactical manifests, and the Azure deployment architecture. **Absent from `VALIDATION-CHECKLIST.md` entirely.**

**Recommended:** the normative requirement is a *separate, identifiable* A2A port; 8444 is the stated convention. Use 8444. When reviewing, fail on **lack of separation**, not on the number.

## What to do when you hit one of these

State the conflict explicitly, apply the recommended reading, and note it in the PR description or compliance checklist. Do not resolve it silently — the divergence between teams is caused by everyone resolving these privately.

**Source:** cross-document analysis of `DIAI_Framework.md`, `VALIDATION-CHECKLIST.md`, `QUICK-REFERENCE.md`, `07-`/`077-tactical-agent-architecture.md`, `readme.md`

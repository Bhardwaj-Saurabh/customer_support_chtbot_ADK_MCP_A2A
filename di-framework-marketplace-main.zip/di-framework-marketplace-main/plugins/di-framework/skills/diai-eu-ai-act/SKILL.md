---
name: diai-eu-ai-act
description: DI AI Framework §4.8 — every agent must have a documented EU AI Act risk classification committed to the repository, with additional controls mandatory only if classified high-risk. Use when creating a new agent, when docs/eu-ai-act-classification.md is missing, when the user asks about regulatory or compliance obligations, when determining whether human oversight or bias monitoring is required, when writing a FRIA, or when someone proposes deferring classification until launch.
---

# §4.8 — EU AI Act risk classification

**MUST — unconditional for all agents.** The classification itself is always required. The additional controls are conditional on its outcome.

## Always required

A documented EU AI Act risk classification committed at `docs/eu-ai-act-classification.md`.

## Conditional on the outcome

| If classified | What becomes mandatory |
|---|---|
| **High-Risk** | Human oversight with defined intervention points · bias monitoring and algorithmic fairness tracking · decision provenance (full traceable audit of each decision, **on top of** CAT) · Fundamental Rights Impact Assessment (FRIA) documented |
| **Not high-risk** | Nothing further. The classification document is still required. CAT/PST audit logging still applies regardless. |

## Suggested document shape

```markdown
# EU AI Act Risk Classification

**Agent:** <name>
**Layer:** Tactical | Strategic
**Classification:** High-Risk | Limited Risk | Minimal Risk
**Assessed:** <date>   **Assessor:** <name>

## Intended purpose
## Who is affected, and how
## Criteria applied and reasoning
## Outcome and required controls
## Review trigger and date
```

## Why this is cheap and its absence is not

Classification is a short document. Without it there is **no defensible position** if a regulator asks, and recovery under audit costs far more than the document ever would.

## When someone asks to skip this

"EU AI Act classification can wait until launch." → **Refuse.** §4.8 requires classification unconditionally; only the extra high-risk controls are conditional on the outcome. It is a short document and must exist **before deployment**.

**Source:** `DIAI_Framework.md` §4.8 · `VALIDATION-CHECKLIST.md` §8 · `08-audit-logging-architecture.md` "EU AI Act Compliance"

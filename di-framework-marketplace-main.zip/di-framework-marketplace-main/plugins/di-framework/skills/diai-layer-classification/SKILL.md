---
name: diai-layer-classification
description: Classify a component as Operational, Tactical, or Strategic under the DI AI Framework three-layer architecture, and produce the mandatory layer-classification document. Use when starting any new agent or component, when the user asks "is this tactical or strategic", when deciding whether an orchestrator is needed, when reviewing whether an existing component is correctly classified, or when docs/layer-classification.md is missing or being written. Also use when deciding whether the framework MUST rules apply at all.
---

# Layer classification — do this before writing code

Every component belongs to **exactly one** layer. The layer determines which requirements are in scope. Misclassification cascades into wrong protocols, wrong observability shape, and wrong review criteria.

## Decision procedure — apply in order, stop at first match

1. Does it **orchestrate multiple business processes**, coordinate multiple agents, or own a workflow end to end? → **Strategic Layer**
2. Does it **execute one specific business task** with bounded scope, and will an orchestrator be able to call it? → **Tactical Layer** (the majority of components)
3. Is it **embedded inside a vendor product** — M365 Copilot, SAP Joule, Salesforce Einstein, ServiceNow Now Assist? → **Operational Layer**

## What each layer means for compliance

| Layer | Rules that apply |
|---|---|
| Operational | Integration patterns only. §4 MUST rules do not fully apply; vendor guidance governs. |
| Tactical | **All of §4.** Plus §15 sizing boundaries. |
| Strategic | All of §4 **plus §5.2**: capability registry queries, business-process metrics, externalised state. |

## Required output before writing code

A one-line statement in `README.md` **and** a committed `docs/layer-classification.md`:

```
Layer: Tactical — executes invoice field extraction; invoked by the
Strategic Dynamic Orchestrator Agent.
```

## Agent classification types

- **Standalone** — direct user interaction; exposes tools via MCP; self-contained logic.
- **Worker** — called by orchestrators; A2A only, never MCP; stateless, horizontally scalable.
- **Orchestrator** — coordinates workflows; queries the Strategic Business Context Agent; **never exposes tools externally** (security boundary).

## Common mistakes

- Classifying a multi-function component as tactical because it "feels small". Run the sizing tests (`diai-agent-sizing`).
- Assuming an agent that runs standalone today will never be orchestrated. If it could be, it is tactical and A2A is mandatory.
- Placing `layer-classification.md` per-agent in a monorepo without one at the validated project root — the validator reads the target root and will skip §4.2 entirely with a WARN.

**Source:** `DIAI_Framework.md` §3 · `00 - AI Framework - Vision.md` · `VALIDATION-CHECKLIST.md` §1 · `01-what-is-an-agent.md`

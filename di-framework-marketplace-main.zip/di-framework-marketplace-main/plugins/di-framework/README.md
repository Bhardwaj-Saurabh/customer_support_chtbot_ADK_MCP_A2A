# DI AI Framework plugin

The DI AI Framework rulebook as Claude Code skills, commands, a compliance-review subagent, and an anti-pattern guard — keeps every engineer and every Claude Code session building agents the same compliant way.

Full documentation, install instructions, and maintenance notes live in the [marketplace README](../../README.md).

#!/usr/bin/env python3
"""DI AI Framework anti-pattern guard.

Runs as a PostToolUse hook after Write/Edit. Scans the edited file for the
§9 anti-patterns that are immediate FAILs and returns them to Claude as
`hookSpecificOutput.additionalContext`, so they land in the conversation and
can be fixed in the same turn.

The JSON envelope is the whole point. A PostToolUse hook that merely prints
to stdout and exits 0 is discarded — the text reaches neither Claude nor the
user, only the transcript. Findings emitted that way are invisible.

Deliberately conservative: it reports only high-confidence patterns, and it
does NOT flag DefaultAzureCredential on its own, because that symbol is
legitimate when authenticating to the gateway or to permitted data-plane
services (see the diai-known-issues skill).

Exit code is always 0 — this advises, it does not block. A clean file emits
nothing at all, so it costs no context.
"""
import json
import re
import sys
from pathlib import Path

RULES = [
    (r"^\s*(from|import)\s+openai\b",              "4.1", "Direct provider SDK import bypasses the AI Gateway"),
    (r"^\s*(from|import)\s+anthropic\b",           "4.1", "Direct provider SDK import bypasses the AI Gateway"),
    (r"\bAzureOpenAI\s*\(",                        "4.1", "Direct AzureOpenAI() client — route through the gateway"),
    (r"\bFoundryChatClient\s*\(",                  "4.1", "Direct Foundry client — route through the gateway"),
    (r"[\"']sk-[A-Za-z0-9]{20,}[\"']",             "4.4", "Hardcoded provider secret literal"),
    (r"[\"']AKIA[0-9A-Z]{16}[\"']",                "4.4", "Hardcoded AWS access key ID"),
    (r"(?i)\b(api[_-]?key|password|secret)\s*=\s*[\"'][^\"'{$][^\"']{12,}[\"']",
                                                   "4.4", "Hardcoded credential assignment"),
    (r"^\s*(?!.*#).*\b\w*_sessions?\s*(:\s*dict[^=]*)?=\s*\{\s*\}\s*$",
                                                   "4.9", "Module-level mutable state — agents must be stateless"),
]

# Dockerfile-specific
DOCKER_RULES = [
    (r"(?i)apt-get\s+install.*dotnet",             "4.9", "Mixed technology stacks in one container"),
    (r"(?i)^FROM\s+\S+:latest",                    "4.9", "Unpinned base image — pin the tag"),
]

SKIP_DIRS = {".venv", "venv", "node_modules", "__pycache__", ".git", "dist", "build", "tests"}


def scan(path: Path):
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    rules = DOCKER_RULES if path.name.lower().startswith("dockerfile") else RULES
    if path.suffix not in {".py", ".yaml", ".yml", ".toml"} and not path.name.lower().startswith("dockerfile"):
        return []
    out = []
    for n, line in enumerate(text.splitlines(), 1):
        if line.lstrip().startswith("#"):
            continue
        for pat, sec, msg in rules:
            if re.search(pat, line):
                out.append((n, sec, msg, line.strip()[:100]))
                break
    return out


def emit(obj):
    """Write UTF-8 bytes straight to the byte stream.

    sys.stdout defaults to the console codepage on Windows — cp1252, where §
    encodes as the lone byte 0xA7 and the JSON is no longer valid UTF-8.
    Bypassing the text layer pins the encoding regardless of platform or
    active codepage.
    """
    data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def main():
    try:
        payload = json.loads(sys.stdin.buffer.read().decode("utf-8", errors="replace"))
    except Exception:
        return 0
    p = (payload.get("tool_input") or {}).get("file_path")
    if not p:
        return 0
    path = Path(p)
    if not path.is_file() or SKIP_DIRS & set(path.parts):
        return 0

    findings = scan(path)
    if not findings:
        return 0

    lines = [f"DI AI Framework anti-pattern check — {path}"]
    for n, sec, msg, snippet in findings:
        lines.append(f"  FAIL §{sec}  line {n}: {msg}")
        lines.append(f"        {snippet}")
    lines.append(
        "  These are immediate FAIL items. Load the matching diai-* skill "
        "and fix before continuing."
    )

    emit({
        "hookSpecificOutput": {
            "hookEventName": "PostToolUse",
            "additionalContext": "\n".join(lines),
        }
    })
    return 0


if __name__ == "__main__":
    sys.exit(main())

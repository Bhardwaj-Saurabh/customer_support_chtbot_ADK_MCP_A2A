# DI Platform — Claude Code marketplace

Internal marketplace distributing the DI AI Framework as a Claude Code plugin, so every engineer and every Claude Code session applies the same rules the same way.

## Prerequisites

Skills, commands and the subagent are plain Markdown and need nothing installed. Only the anti-pattern hook has requirements.

| Requirement | Why | If missing |
|---|---|---|
| **Python 3.8+** on `PATH` as `python3` or `python` | Runs `scripts/check_antipatterns.py` after each `Write`/`Edit` | Hook no-ops silently; everything else works |
| **Git for Windows** (Windows only) | The hook is pinned to `shell: "bash"` | Hook cannot run; everything else works |

The hook probes `python3` first, then `python`, and exits 0 either way. A missing interpreter is never an error — you lose the anti-pattern warnings, not the session. Standard library only; there is nothing to `pip install`.

Verify with:

```bash
python3 --version || python --version
```

On Windows the interpreter is normally the Git for Windows or python.org build. The `python3` shim under `WindowsApps` is an App Execution Alias that opens the Microsoft Store when Python is *not* installed, so confirm the command actually prints a version rather than assuming the alias means it is present.

## Install

```bash
/plugin marketplace add https://github.com/DLW-INT-IMAMOR/di-framework-marketplace.git
/plugin install di-framework@di-platform
```

Use the full HTTPS URL, not the `owner/repo` shorthand. The shorthand clones over SSH (`git@github.com:`), which fails on any machine without an SSH key registered on GitHub — see [Authentication](#authentication).

For local testing before you push it anywhere:

```bash
/plugin marketplace add ./di-framework-marketplace
/plugin install di-framework@di-platform
/plugin validate ./di-framework-marketplace
```

## Enrol a project automatically

Commit this to a project's `.claude/settings.json`. Claude Code adds the marketplace once the person trusts the folder — no separate install step, and updates arrive without anyone copying files.

```json
{
  "extraKnownMarketplaces": {
    "di-platform": {
      "source": {
        "source": "git",
        "url": "https://github.com/DLW-INT-IMAMOR/di-framework-marketplace.git"
      }
    }
  },
  "enabledPlugins": {
    "di-framework@di-platform": true
  }
}
```

Add this block to the agent templates so new projects are enrolled from their first commit.

Note the source type is `git` with a `url`, not `github` with a `repo`. Both are valid Claude Code source types, but `github` resolves to an SSH clone, and this repository is reached over HTTPS.

## Authentication

The repository is private, so every consumer needs git credentials that can read it. Getting this wrong fails quietly: the clone errors during marketplace-add and the plugin simply never loads, with no message pointing at credentials.

### Start here: the readiness check

Run this before touching a settings file. It is the same non-interactive fetch Claude Code performs, so it answers the only question that matters — will enrolment work on this machine?

```bash
GIT_TERMINAL_PROMPT=0 GCM_INTERACTIVE=never \
  git ls-remote https://github.com/DLW-INT-IMAMOR/di-framework-marketplace.git HEAD
```

A commit SHA means enrolment will work. Anything else means it will not, whatever the settings file says. Two seconds here replaces an unexplained "the plugin doesn't work".

Note that an ordinary `git clone` or `git fetch` is **not** a valid substitute. Those run interactively and succeed on machines where enrolment still fails — that gap is precisely what makes this failure so confusing.

### If the check fails

Three causes are known. Match on the error text; the check is authoritative, this list is not exhaustive.

| Error | Cause | Fix |
|---|---|---|
| `could not read Username` / `unable to get password from user` | No credential helper visible. Git for Windows defines `credential.helper=manager` in the *system* config only, and it disappears whenever git runs without system config. | `git config --global credential.helper manager` |
| `Cannot prompt because user interactivity has been disabled` | A helper is present and a valid token is stored, but GCM's GitHub provider wants an interactive OAuth flow and aborts rather than returning it. | `git config --global "credential.https://github.com.provider" generic` |
| `Permission denied (publickey)` / `No ED25519 host key is known` | Enrolled via the `github`/`owner/repo` source, which clones over SSH, on a machine with no SSH key. | Use the `git` + HTTPS source shown above |

The second one is the trap. The message says nothing about providers and everything about prompting, so the natural reading is that the credential is missing or expired — and rotating a token that was never wrong changes nothing. If `GCM_PROVIDER=generic` makes the same fetch succeed, the credential was always fine and the provider was the problem.

Re-run the readiness check after each change rather than applying all three blind. A machine configured with a different credential helper — plain `store`, a corporate SSO helper, no GCM at all — may need something not listed here, and applying these fixes to it can make things worse rather than better.

SSH is the clean alternative: register a key on GitHub and the `owner/repo` form works with none of the GCM workarounds. Worth standardising on if your team already manages keys.

## What the plugin contains

**17 skills** — loaded automatically when relevant.

| Skill | Covers |
|---|---|
| `diai-rulebook` | Router. The ten §4 rules, §5 conditionals, §6 choices, terminology |
| `diai-layer-classification` | §3 — Operational / Tactical / Strategic |
| `diai-agent-sizing` | §15 — four sizing tests, workflow vs orchestration |
| `diai-gateway-routing` | §4.1 — AI Gateway |
| `diai-a2a-protocol` | §4.2 — A2A surface and port |
| `diai-observability-audit` | §4.3 — OTel, health probes, CAT/PST |
| `diai-security-auth` | §4.4, §4.5 — auth, secrets, correlation IDs |
| `diai-tool-isolation` | §4.6 — tools over the network |
| `diai-semantic-plane` | §4.7 — business rules from the semantic plane |
| `diai-eu-ai-act` | §4.8 — risk classification |
| `diai-container-hygiene` | §4.9 — containers, naming, statelessness |
| `diai-resilience` | §4.10 — breakers, retries, timeouts |
| `diai-scaffold` | §7 — project structure, twelve-phase process |
| `diai-evals-metrics` | STAR, hierarchical evals, compliance evals |
| `diai-compliance-review` | Severity model and review procedure |
| `diai-common-requests` | Standard responses when asked to skip a rule |
| `diai-known-issues` | The four specification contradictions and how to handle them |

**5 commands**

| Command | Does |
|---|---|
| `/di-framework:classify` | Classify the layer and run the sizing tests |
| `/di-framework:review` | Severity-tiered compliance review |
| `/di-framework:checklist` | Generate or refresh `docs/compliance-checklist.md` |
| `/di-framework:new-capability` | Add an A2A-compliant capability |
| `/di-framework:gateway-check` | Audit every LLM call path |

**1 subagent** — `diai-compliance-reviewer`, read-only, for pre-PR review.

**1 hook** — `PostToolUse` on `Write|Edit` runs `scripts/check_antipatterns.py`. Findings come back as `hookSpecificOutput.additionalContext` on stdout, which is what puts them in front of Claude so they get fixed in the same turn:

```json
{"hookSpecificOutput": {"hookEventName": "PostToolUse", "additionalContext": "…findings…"}}
```

The envelope is load-bearing. A `PostToolUse` hook that prints plain text and exits 0 has its output discarded — it reaches neither Claude nor the user, only the transcript — so findings emitted that way are invisible. Advisory either way: it never blocks, and a clean file emits nothing at all, so it costs no context.

## Design notes worth knowing

**The hook is deliberately conservative.** It does not flag `DefaultAzureCredential` on its own, because that symbol is legitimate when authenticating *to* the gateway or to permitted data-plane services. Flagging it produces false alarms, and a noisy hook gets disabled.

**`diai-known-issues` exists because the specification contradicts itself** in four places — resilience severity, health-probe paths, two validators, and two versions of the tactical architecture document. Each skill that touches a disputed rule cross-references it and states the recommended reading. Hiding the conflicts would just push every team to resolve them privately, which is what produced the divergence in the first place.

**Skills cite their sources.** Every skill ends with the source documents and sections it derives from, so an engineer can go to the original when the summary is not enough.

## Maintaining this

Skills are the interpretation layer; the specification is the authority. When a source document changes, update the affected skill and bump `plugins/di-framework/.claude-plugin/plugin.json`. Users receive it on the next `/plugin update`.

This needs a named owner. An unmaintained rulebook is worse than no rulebook, because people trust it.

### `/plugin marketplace update` is not `/plugin update`

The two commands do different things. `/plugin marketplace update` refreshes the cached copy of this repository — it does not touch what a consumer has installed. `/plugin update` is what actually moves their pinned, installed record forward to the new version. Bumping `plugin.json` and running only the first leaves every consumer on the old version with no error to indicate it. Both commands are required before a version bump actually reaches anyone.

### Diagnosing a stuck enrolment

Start with the readiness check, not the settings file — it's the same non-interactive fetch Claude Code performs, so it answers the only question that matters:

```bash
GIT_TERMINAL_PROMPT=0 GCM_INTERACTIVE=never \
  git ls-remote <repo-url> HEAD
```

A commit SHA means the machine can enrol; anything else means it can't, whatever `.claude/settings.json` says. Three causes have been seen so far — no SSH key registered, so the `owner/repo` shorthand fails; `credential.helper` defined only in the *system* gitconfig, so it disappears when git runs without system config; and GCM refusing to answer non-interactively even with a valid stored credential. See [Authentication](#authentication) above for the fix matching each one.
